<?php

declare(strict_types=1);

namespace SafeContracts\Payments;

use DateTimeImmutable;
use DomainException;
use InvalidArgumentException;
use SafeContracts\Contracts\ContractMoney;
use SafeContracts\Roles\Capabilities;

final class PaymentService
{
    public function __construct(private ?PaymentRepository $repository = null)
    {
        $this->repository ??= new PaymentRepository();
    }

    /** @param array{contract_id:mixed, sequence_no?:mixed, reference?:mixed, due_date:mixed, expected_payment_date?:mixed, original_amount:mixed} $input */
    public function create(array $input): int
    {
        $this->requireCapability(Capabilities::MANAGE_PAYMENTS, 'You do not have permission to manage payments.');

        $contractId = (int) ($input['contract_id'] ?? 0);
        if ($contractId <= 0) {
            throw new InvalidArgumentException('Payment contract ID must be positive.');
        }
        $contract = $this->repository->contractContext($contractId);
        if ($contract === null) {
            throw new InvalidArgumentException('Payment contract was not found.');
        }
        $this->assertScope($contract['accountant_user_id']);
        if ($contract['is_archived']) {
            throw new DomainException('Archived contracts cannot receive scheduled payments.');
        }

        $reference = $this->normalizeReference($input['reference'] ?? null);
        $dueDate = $this->normalizeRequiredDate($input['due_date'] ?? null, 'due date');
        $expectedPaymentDate = $this->normalizeOptionalDate($input['expected_payment_date'] ?? null, 'expected payment date');
        $amount = ContractMoney::normalizeNonNegative($input['original_amount'] ?? '');
        if ($amount === '0.0000') {
            throw new InvalidArgumentException('Payment original amount must be greater than zero.');
        }
        $this->assertCreateWithinContractValue($contract, $amount);

        $actorId = get_current_user_id();
        $sequenceNo = (int) ($input['sequence_no'] ?? 0);
        if ($sequenceNo > 0) {
            // Backward-compatible path for existing integrations/mobile callers.
            $paymentId = $this->repository->create(
                $contractId,
                $sequenceNo,
                $reference,
                $dueDate,
                $expectedPaymentDate,
                $amount,
                $actorId,
                $contract['financial_direction'],
                $contract['currency_code']
            );
        } else {
            // Admin/backend creation owns sequence allocation; users should not
            // have to discover or guess a database ordering value.
            $created = $this->repository->createAutoSequenced(
                $contractId,
                $reference,
                $dueDate,
                $expectedPaymentDate,
                $amount,
                $actorId,
                $contract['financial_direction'],
                $contract['currency_code']
            );
            $paymentId = $created['id'];
            $sequenceNo = $created['sequence_no'];
        }

        do_action(
            'safecontracts_payment_created',
            $paymentId,
            $contractId,
            $sequenceNo,
            $dueDate,
            $expectedPaymentDate,
            $amount,
            $actorId
        );
        do_action(
            'safecontracts_payment_financial_context_assigned',
            $paymentId,
            $contractId,
            $contract['financial_direction'],
            $contract['currency_code'],
            $actorId
        );
        return $paymentId;
    }

    /** @return array<string,mixed> */
    public function find(int $paymentId): array
    {
        $this->requireCapability(Capabilities::ACCESS, 'You do not have access to SafeContracts payments.');
        $payment = $this->requirePayment($paymentId);
        $this->assertScope($payment['accountant_user_id']);
        return $payment;
    }

    public function changeStatus(int $paymentId, mixed $targetStatus): void
    {
        $this->requireCapability(Capabilities::MANAGE_PAYMENTS, 'You do not have permission to manage payments.');
        $payment = $this->editablePayment($paymentId);
        $target = PaymentStatus::normalize($targetStatus);
        $current = PaymentStatus::normalize($payment['status']);
        PaymentStatus::assertTransition($current, $target);
        if ($current === $target) {
            return;
        }
        $actorId = get_current_user_id();
        $this->repository->updateStatus($paymentId, $target, $actorId);
        do_action('safecontracts_payment_status_changed', $paymentId, $current, $target, $actorId);
    }

    public function updateDates(int $paymentId, mixed $dueDate, mixed $expectedPaymentDate): void
    {
        $this->requireCapability(Capabilities::MANAGE_PAYMENTS, 'You do not have permission to manage payment dates.');
        $payment = $this->editablePayment($paymentId);
        $due = $this->normalizeRequiredDate($dueDate, 'due date');
        $expected = $this->normalizeOptionalDate($expectedPaymentDate, 'expected payment date');
        $actorId = get_current_user_id();
        $this->repository->updateDates($paymentId, $due, $expected, $actorId);
        do_action('safecontracts_payment_dates_changed', $paymentId, $payment['due_date'], $due, $payment['expected_payment_date'], $expected, $actorId);
    }

    /** @param array{reference?:mixed,due_date:mixed,expected_payment_date?:mixed,original_amount?:mixed} $input */
    public function updateEditable(int $paymentId, array $input): void
    {
        $this->requireCapability(Capabilities::MANAGE_PAYMENTS, 'You do not have permission to manage payment details.');
        $payment = $this->editablePayment($paymentId);
        $reference = $this->normalizeReference($input['reference'] ?? $payment['reference']);
        $due = $this->normalizeRequiredDate($input['due_date'] ?? null, 'due date');
        $expected = $this->normalizeOptionalDate($input['expected_payment_date'] ?? null, 'expected payment date');
        $original = ContractMoney::normalizeNonNegative($payment['original_amount']);
        $paid = ContractMoney::normalizeNonNegative($payment['paid_amount']);
        $amount = array_key_exists('original_amount', $input) ? ContractMoney::normalizeNonNegative($input['original_amount']) : $original;
        if ($amount === '0.0000') {
            throw new InvalidArgumentException('Payment original amount must be greater than zero.');
        }
        if (ContractMoney::compare($paid, '0.0000') > 0 && ContractMoney::compare($amount, $original) !== 0) {
            throw new DomainException('Payment original amount cannot change after settlement activity exists.');
        }
        if (ContractMoney::compare($amount, $original) !== 0) {
            $this->assertEditWithinContractValue($payment, $original, $amount);
        }
        $remaining = ContractMoney::compare($paid, '0.0000') === 0 ? $amount : ContractMoney::normalizeNonNegative($payment['remaining_amount']);
        $actorId = get_current_user_id();
        $this->repository->updateEditable($paymentId, $reference, $due, $expected, $amount, $remaining, $actorId);

        do_action(
            'safecontracts_payment_details_changed',
            $paymentId,
            [
                'reference' => $payment['reference'],
                'due_date' => $payment['due_date'],
                'expected_payment_date' => $payment['expected_payment_date'],
                'original_amount' => $original,
                'remaining_amount' => $payment['remaining_amount'],
            ],
            [
                'reference' => $reference,
                'due_date' => $due,
                'expected_payment_date' => $expected,
                'original_amount' => $amount,
                'remaining_amount' => $remaining,
            ],
            $actorId
        );
        if ($payment['due_date'] !== $due || $payment['expected_payment_date'] !== $expected) {
            do_action('safecontracts_payment_dates_changed', $paymentId, $payment['due_date'], $due, $payment['expected_payment_date'], $expected, $actorId);
        }
    }

    public function effectiveDate(int $paymentId): string
    {
        $payment = $this->requirePayment($paymentId);
        $this->assertScope($payment['accountant_user_id']);
        if ($payment['is_archived']) {
            throw new DomainException('Archived payments are not available for operational follow-up.');
        }
        return $payment['expected_payment_date'] ?? $payment['due_date'];
    }

    public function temporalStatus(int $paymentId, ?DateTimeImmutable $today = null, int $dueSoonDays = 10): string
    {
        $this->requireCapability(Capabilities::ACCESS, 'You do not have access to SafeContracts payments.');
        $payment = $this->requirePayment($paymentId);
        $this->assertScope($payment['accountant_user_id']);
        if ($payment['is_archived']) {
            throw new DomainException('Archived payments are not part of the operational schedule.');
        }
        $current = PaymentStatus::normalize($payment['status']);
        if ($current === PaymentStatus::PAID || $current === PaymentStatus::PARTIALLY_PAID) {
            return $current;
        }
        return PaymentStatus::temporalForDueDate($payment['due_date'], $today, $dueSoonDays);
    }

    public function isDueSoon(int $paymentId, ?DateTimeImmutable $today = null, int $dueSoonDays = 10): bool
    {
        return $this->temporalStatus($paymentId, $today, $dueSoonDays) === PaymentStatus::DUE_SOON;
    }

    public function isOverdue(int $paymentId, ?DateTimeImmutable $today = null): bool
    {
        return $this->temporalStatus($paymentId, $today) === PaymentStatus::OVERDUE;
    }

    /** @param array<string,mixed> $contract */
    private function assertCreateWithinContractValue(array $contract, string $amount): void
    {
        if (($contract['base_value'] ?? null) === null || ($contract['scheduled_total'] ?? null) === null) {
            return;
        }
        $contractValue = ContractMoney::normalizeNonNegative((string) $contract['base_value']);
        $scheduled = ContractMoney::normalizeNonNegative((string) $contract['scheduled_total']);
        $projected = ContractMoney::add($scheduled, $amount);
        if (ContractMoney::compare($projected, $contractValue) <= 0) {
            return;
        }
        $available = ContractMoney::compare($scheduled, $contractValue) >= 0
            ? '0.0000'
            : ContractMoney::subtract($contractValue, $scheduled);
        throw new DomainException(
            "Scheduled payments cannot exceed the contract value. Contract value: {$contractValue}; already scheduled: {$scheduled}; maximum additional amount: {$available}."
        );
    }

    /** @param array<string,mixed> $payment */
    private function assertEditWithinContractValue(array $payment, string $currentAmount, string $newAmount): void
    {
        if (($payment['contract_base_value'] ?? null) === null || ($payment['contract_scheduled_total'] ?? null) === null) {
            return;
        }
        $contractValue = ContractMoney::normalizeNonNegative((string) $payment['contract_base_value']);
        $scheduled = ContractMoney::normalizeNonNegative((string) $payment['contract_scheduled_total']);
        $otherScheduled = ContractMoney::compare($scheduled, $currentAmount) >= 0
            ? ContractMoney::subtract($scheduled, $currentAmount)
            : '0.0000';
        $projected = ContractMoney::add($otherScheduled, $newAmount);
        if (ContractMoney::compare($projected, $contractValue) <= 0) {
            return;
        }
        $available = ContractMoney::compare($otherScheduled, $contractValue) >= 0
            ? '0.0000'
            : ContractMoney::subtract($contractValue, $otherScheduled);
        throw new DomainException(
            "Scheduled payments cannot exceed the contract value. Contract value: {$contractValue}; other scheduled payments: {$otherScheduled}; maximum value for this payment: {$available}."
        );
    }

    /** @return array<string,mixed> */
    private function editablePayment(int $paymentId): array
    {
        $payment = $this->requirePayment($paymentId);
        $this->assertScope($payment['accountant_user_id']);
        if ($payment['is_archived']) {
            throw new DomainException('Archived payments cannot be edited.');
        }
        if ($payment['contract_is_archived']) {
            throw new DomainException('Payments on archived contracts cannot be edited.');
        }
        return $payment;
    }

    /** @return array<string,mixed> */
    private function requirePayment(int $paymentId): array
    {
        if ($paymentId <= 0) {
            throw new InvalidArgumentException('Payment ID must be positive.');
        }
        $payment = $this->repository->find($paymentId);
        if ($payment === null) {
            throw new InvalidArgumentException('Payment was not found.');
        }
        return $payment;
    }

    private function assertScope(?int $accountantUserId): void
    {
        if (current_user_can(Capabilities::VIEW_ALL)) {
            return;
        }
        if (current_user_can(Capabilities::VIEW_ASSIGNED) && $accountantUserId !== null && $accountantUserId === get_current_user_id()) {
            return;
        }
        throw new DomainException('Payment is outside the current user data scope.');
    }

    private function normalizeReference(mixed $value): ?string
    {
        if ($value === null || trim((string) $value) === '') {
            return null;
        }
        $reference = trim((string) $value);
        if (strlen($reference) > 100) {
            throw new InvalidArgumentException('Payment description must not exceed 100 characters.');
        }
        return $reference;
    }

    private function normalizeRequiredDate(mixed $value, string $field): string
    {
        $date = $this->normalizeOptionalDate($value, $field);
        if ($date === null) {
            throw new InvalidArgumentException("Payment {$field} is required.");
        }
        return $date;
    }

    private function normalizeOptionalDate(mixed $value, string $field): ?string
    {
        if ($value === null || trim((string) $value) === '') {
            return null;
        }
        $date = trim((string) $value);
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        if (! $parsed || $parsed->format('Y-m-d') !== $date) {
            throw new InvalidArgumentException("Payment {$field} must use YYYY-MM-DD and be a valid calendar date.");
        }
        return $date;
    }

    private function requireCapability(string $capability, string $message): void
    {
        if (! current_user_can($capability)) {
            throw new DomainException($message);
        }
    }
}
