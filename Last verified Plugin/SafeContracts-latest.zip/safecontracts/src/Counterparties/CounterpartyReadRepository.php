<?php

declare(strict_types=1);

namespace SafeContracts\Counterparties;

use DomainException;
use InvalidArgumentException;
use SafeContracts\Admin\DashboardFilters;
use SafeContracts\Payments\PaymentStatus;
use SafeContracts\Roles\Capabilities;

final class CounterpartyReadRepository
{
    /** @return list<array<string,mixed>> */
    public function contracts(array $filters = []): array
    {
        global $wpdb;
        $f = DashboardFilters::normalize($filters);
        $contracts = $wpdb->prefix . 'safecontracts_contracts';
        $customers = $wpdb->prefix . 'safecontracts_customers';
        $suppliers = $wpdb->prefix . 'safecontracts_suppliers';
        $where = $this->where($f, 'c', null);
        $where[] = 'c.is_archived = 0';
        $sql = "SELECT c.id, c.contract_number, c.customer_id,
                       c.counterparty_type, c.counterparty_id,
                       CASE WHEN c.counterparty_type = 'customer' THEN cu.name ELSE su.name END AS counterparty_name,
                       CASE WHEN c.counterparty_type = 'customer' THEN cu.name ELSE NULL END AS customer_name,
                       CASE WHEN c.counterparty_type = 'supplier' THEN su.id ELSE NULL END AS supplier_id,
                       CASE WHEN c.counterparty_type = 'supplier' THEN su.name ELSE NULL END AS supplier_name,
                       c.financial_direction, c.currency_code, c.accountant_user_id,
                       c.status, c.start_date, c.end_date, c.base_value, c.notes, c.is_archived, c.created_at, c.updated_at
                FROM {$contracts} c
                LEFT JOIN {$customers} cu ON c.counterparty_type = 'customer' AND cu.id = c.counterparty_id
                LEFT JOIN {$suppliers} su ON c.counterparty_type = 'supplier' AND su.id = c.counterparty_id
                WHERE " . implode(' AND ', $where) . '
                ORDER BY c.updated_at DESC, c.id DESC LIMIT 500';
        return $this->rows($wpdb->get_results($sql, ARRAY_A));
    }

    /**
     * Server-authoritative contract pagination. Each request executes one
     * bounded COUNT plus one bounded LIMIT/OFFSET query; the full dataset is
     * never materialized in PHP before paging.
     *
     * @return array{rows:list<array<string,mixed>>,total:int}
     */
    public function contractPage(
        array $filters,
        string $search,
        string $sort,
        string $order,
        int $page,
        int $perPage
    ): array {
        global $wpdb;
        if ($page < 1 || $perPage < 1 || $perPage > 100) {
            throw new InvalidArgumentException('Contract pagination is outside the allowed range.');
        }
        $offset = ($page - 1) * $perPage;
        if ($offset > 1000000) {
            throw new InvalidArgumentException('Contract pagination offset is outside the bounded query window.');
        }

        $sortColumns = [
            'id' => 'c.id',
            'contract_number' => 'c.contract_number',
            'customer_name' => 'customer_name',
            'counterparty_name' => 'counterparty_name',
            'financial_direction' => 'c.financial_direction',
            'currency_code' => 'c.currency_code',
            'status' => 'c.status',
            'start_date' => 'c.start_date',
            'end_date' => 'c.end_date',
        ];
        if (! array_key_exists($sort, $sortColumns)) {
            throw new InvalidArgumentException('Contract sort is not supported.');
        }
        $direction = strtolower($order);
        if (! in_array($direction, ['asc', 'desc'], true)) {
            throw new InvalidArgumentException('Contract sort order is invalid.');
        }

        $f = DashboardFilters::normalize($filters);
        [$where, $args] = $this->contractPageWhere($f, $search);
        $contracts = $wpdb->prefix . 'safecontracts_contracts';
        $customers = $wpdb->prefix . 'safecontracts_customers';
        $suppliers = $wpdb->prefix . 'safecontracts_suppliers';
        $joins = "LEFT JOIN {$customers} cu ON c.counterparty_type = 'customer' AND cu.id = c.counterparty_id\n"
            . "LEFT JOIN {$suppliers} su ON c.counterparty_type = 'supplier' AND su.id = c.counterparty_id";
        $whereSql = implode(' AND ', $where);

        $countSql = "SELECT COUNT(c.id) AS total\n"
            . "FROM {$contracts} c\n{$joins}\nWHERE {$whereSql}";
        if ($args !== []) {
            $countSql = $wpdb->prepare($countSql, ...$args);
        }
        $countRows = $this->rows($wpdb->get_results($countSql, ARRAY_A));
        $total = max(0, (int) ($countRows[0]['total'] ?? 0));

        $orderColumn = $sortColumns[$sort];
        $sql = "SELECT c.id, c.contract_number, c.customer_id,\n"
            . "       c.counterparty_type, c.counterparty_id,\n"
            . "       CASE WHEN c.counterparty_type = 'customer' THEN cu.name ELSE su.name END AS counterparty_name,\n"
            . "       CASE WHEN c.counterparty_type = 'customer' THEN cu.name ELSE NULL END AS customer_name,\n"
            . "       CASE WHEN c.counterparty_type = 'supplier' THEN su.id ELSE NULL END AS supplier_id,\n"
            . "       CASE WHEN c.counterparty_type = 'supplier' THEN su.name ELSE NULL END AS supplier_name,\n"
            . "       c.financial_direction, c.currency_code, c.accountant_user_id,\n"
            . "       c.status, c.start_date, c.end_date, c.base_value, c.notes, c.is_archived, c.created_at, c.updated_at\n"
            . "FROM {$contracts} c\n{$joins}\nWHERE {$whereSql}\n"
            . 'ORDER BY ' . $orderColumn . ' ' . strtoupper($direction)
            . ($orderColumn === 'c.id' ? '' : ', c.id ' . strtoupper($direction))
            . " LIMIT %d OFFSET %d";
        $pageArgs = [...$args, $perPage, $offset];
        $sql = $wpdb->prepare($sql, ...$pageArgs);
        $rows = $this->rows($wpdb->get_results($sql, ARRAY_A));

        return ['rows' => $rows, 'total' => $total];
    }

    /** @return list<array<string,mixed>> */
    public function payments(array $filters = []): array
    {
        global $wpdb;
        $f = DashboardFilters::normalize($filters);
        $payments = $wpdb->prefix . 'safecontracts_scheduled_payments';
        $contracts = $wpdb->prefix . 'safecontracts_contracts';
        $customers = $wpdb->prefix . 'safecontracts_customers';
        $suppliers = $wpdb->prefix . 'safecontracts_suppliers';
        $where = $this->where($f, 'c', 'p');
        $where[] = 'c.is_archived = 0';
        $where[] = 'p.is_archived = 0';
        $sql = "SELECT p.id, p.contract_id, p.financial_direction, p.currency_code, p.sequence_no, p.reference,
                       p.due_date, p.expected_payment_date, p.original_amount, p.paid_amount, p.remaining_amount,
                       p.status, p.is_archived, c.contract_number, c.accountant_user_id,
                       c.is_archived AS contract_is_archived, c.customer_id, c.counterparty_type, c.counterparty_id,
                       CASE WHEN c.counterparty_type = 'customer' THEN cu.name ELSE su.name END AS counterparty_name,
                       CASE WHEN c.counterparty_type = 'customer' THEN cu.name ELSE NULL END AS customer_name,
                       CASE WHEN c.counterparty_type = 'supplier' THEN su.id ELSE NULL END AS supplier_id,
                       CASE WHEN c.counterparty_type = 'supplier' THEN su.name ELSE NULL END AS supplier_name
                FROM {$payments} p
                INNER JOIN {$contracts} c ON c.id = p.contract_id
                LEFT JOIN {$customers} cu ON c.counterparty_type = 'customer' AND cu.id = c.counterparty_id
                LEFT JOIN {$suppliers} su ON c.counterparty_type = 'supplier' AND su.id = c.counterparty_id
                WHERE " . implode(' AND ', $where) . '
                ORDER BY p.due_date ASC, p.sequence_no ASC LIMIT 500';
        return $this->authoritativePaymentRows(
            $this->rows($wpdb->get_results($sql, ARRAY_A)),
            (string) ($f['status'] ?? '')
        );
    }

    /** @return list<array<string,mixed>> */
    public function settlements(array $filters = []): array
    {
        global $wpdb;
        $f = DashboardFilters::normalize($filters);
        $collections = $wpdb->prefix . 'safecontracts_payment_collections';
        $payments = $wpdb->prefix . 'safecontracts_scheduled_payments';
        $contracts = $wpdb->prefix . 'safecontracts_contracts';
        $customers = $wpdb->prefix . 'safecontracts_customers';
        $suppliers = $wpdb->prefix . 'safecontracts_suppliers';
        $methods = $wpdb->prefix . 'safecontracts_payment_methods';
        $where = $this->where($f, 'c', 'p');
        $where[] = 'c.is_archived = 0';
        $where[] = 'p.is_archived = 0';
        $where[] = 'cl.is_archived = 0';
        $sql = "SELECT cl.id, cl.payment_id, cl.financial_direction, cl.currency_code, cl.amount, cl.collection_date,
                       cl.payment_method_id, pm.name AS payment_method_name, cl.reference, cl.details, cl.proof_media_id,
                       cl.created_by, cl.created_at, p.reference AS payment_reference, p.sequence_no, p.due_date,
                       p.status AS payment_status, p.paid_amount, p.remaining_amount, c.id AS contract_id, c.contract_number,
                       c.accountant_user_id, c.customer_id, c.counterparty_type, c.counterparty_id,
                       CASE WHEN c.counterparty_type = 'customer' THEN cu.name ELSE su.name END AS counterparty_name,
                       CASE WHEN c.counterparty_type = 'customer' THEN cu.name ELSE NULL END AS customer_name,
                       CASE WHEN c.counterparty_type = 'supplier' THEN su.id ELSE NULL END AS supplier_id,
                       CASE WHEN c.counterparty_type = 'supplier' THEN su.name ELSE NULL END AS supplier_name
                FROM {$collections} cl
                INNER JOIN {$payments} p ON p.id = cl.payment_id
                INNER JOIN {$contracts} c ON c.id = p.contract_id
                LEFT JOIN {$customers} cu ON c.counterparty_type = 'customer' AND cu.id = c.counterparty_id
                LEFT JOIN {$suppliers} su ON c.counterparty_type = 'supplier' AND su.id = c.counterparty_id
                INNER JOIN {$methods} pm ON pm.id = cl.payment_method_id
                WHERE " . implode(' AND ', $where) . '
                ORDER BY cl.collection_date DESC, cl.id DESC LIMIT 500';
        return $this->authoritativeSettlementRows(
            $this->rows($wpdb->get_results($sql, ARRAY_A)),
            (string) ($f['status'] ?? '')
        );
    }

    /**
     * Currency-safe AP/AR metrics. Amounts are never summed across different
     * currencies or directions; every row is one financial bucket.
     *
     * @return list<array<string,mixed>>
     */
    public function financialSummary(array $filters = []): array
    {
        global $wpdb;
        $f = DashboardFilters::normalize($filters);
        $payments = $wpdb->prefix . 'safecontracts_scheduled_payments';
        $contracts = $wpdb->prefix . 'safecontracts_contracts';
        $where = $this->where($f, 'c', 'p');
        $where[] = 'c.is_archived = 0';
        $where[] = 'p.is_archived = 0';
        $sql = "SELECT p.financial_direction, p.currency_code,
                       COUNT(p.id) AS obligation_count,
                       COALESCE(SUM(p.original_amount), 0.0000) AS scheduled_total,
                       COALESCE(SUM(p.paid_amount), 0.0000) AS settled_total,
                       COALESCE(SUM(p.remaining_amount), 0.0000) AS outstanding_total
                FROM {$payments} p
                INNER JOIN {$contracts} c ON c.id = p.contract_id
                WHERE " . implode(' AND ', $where) . '
                GROUP BY p.financial_direction, p.currency_code
                ORDER BY p.financial_direction ASC, p.currency_code ASC';
        return $this->rows($wpdb->get_results($sql, ARRAY_A));
    }

    /** @return list<string> */
    private function where(array $filters, string $contractAlias, ?string $paymentAlias): array
    {
        if (! current_user_can(Capabilities::ACCESS)) {
            throw new DomainException('SafeContracts counterparty data requires access capability.');
        }
        $where = ['1 = 1'];
        if (current_user_can(Capabilities::VIEW_ALL)) {
            if ($filters['accountant_user_id'] > 0) {
                $where[] = $contractAlias . '.accountant_user_id = ' . (int) $filters['accountant_user_id'];
            }
        } else {
            if (! current_user_can(Capabilities::VIEW_ASSIGNED)) {
                throw new DomainException('SafeContracts counterparty data is outside the current user scope.');
            }
            $where[] = $contractAlias . '.accountant_user_id = ' . get_current_user_id();
        }

        if ($filters['customer_id'] > 0) {
            $where[] = $contractAlias . '.customer_id = ' . (int) $filters['customer_id'];
        }
        if ($filters['counterparty_type'] !== '') {
            $where[] = $contractAlias . ".counterparty_type = '" . addslashes($filters['counterparty_type']) . "'";
        }
        if ($filters['counterparty_id'] > 0) {
            $where[] = $contractAlias . '.counterparty_id = ' . (int) $filters['counterparty_id'];
        }
        if ($filters['contract_id'] > 0) {
            $where[] = $contractAlias . '.id = ' . (int) $filters['contract_id'];
        }
        $directionAlias = $paymentAlias ?? $contractAlias;
        if ($filters['financial_direction'] !== '') {
            $where[] = $directionAlias . ".financial_direction = '" . addslashes($filters['financial_direction']) . "'";
        }
        if ($filters['currency_code'] !== '') {
            $where[] = $directionAlias . ".currency_code = '" . addslashes($filters['currency_code']) . "'";
        }
        if ($filters['status'] !== '') {
            $paymentStatuses = ['upcoming', 'due_soon', 'due', 'overdue', 'partially_paid', 'paid'];
            if ($paymentAlias === null || ! in_array($filters['status'], $paymentStatuses, true)) {
                $where[] = $contractAlias . ".status = '" . addslashes($filters['status']) . "'";
            }
        }
        if ($paymentAlias !== null) {
            if ($filters['due_from'] !== null) {
                $where[] = $paymentAlias . ".due_date >= '" . addslashes($filters['due_from']) . "'";
            }
            if ($filters['due_to'] !== null) {
                $where[] = $paymentAlias . ".due_date <= '" . addslashes($filters['due_to']) . "'";
            }
        }
        return $where;
    }

    /** @param list<array<string,mixed>> $rows @return list<array<string,mixed>> */
    private function authoritativePaymentRows(array $rows, string $statusFilter): array
    {
        $paymentStatuses = PaymentStatus::all();
        $filter = in_array($statusFilter, $paymentStatuses, true) ? $statusFilter : '';
        $result = [];
        foreach ($rows as $row) {
            $row['status'] = PaymentStatus::authoritative(
                $row['due_date'] ?? '',
                $row['paid_amount'] ?? '0.0000',
                $row['remaining_amount'] ?? '0.0000'
            );
            if ($filter === '' || $row['status'] === $filter) {
                $result[] = $row;
            }
        }
        return $result;
    }

    /** @param list<array<string,mixed>> $rows @return list<array<string,mixed>> */
    private function authoritativeSettlementRows(array $rows, string $statusFilter): array
    {
        $paymentStatuses = PaymentStatus::all();
        $filter = in_array($statusFilter, $paymentStatuses, true) ? $statusFilter : '';
        $result = [];
        foreach ($rows as $row) {
            $row['payment_status'] = PaymentStatus::authoritative(
                $row['due_date'] ?? '',
                $row['paid_amount'] ?? '0.0000',
                $row['remaining_amount'] ?? '0.0000'
            );
            if ($filter === '' || $row['payment_status'] === $filter) {
                unset($row['paid_amount']);
                $result[] = $row;
            }
        }
        return $result;
    }

    /** @return array{0:list<string>,1:list<int|string>} */
    private function contractPageWhere(array $filters, string $search): array
    {
        if (! current_user_can(Capabilities::ACCESS)) {
            throw new DomainException('SafeContracts counterparty data requires access capability.');
        }
        $where = ['1 = 1', 'c.is_archived = 0'];
        $args = [];
        if (current_user_can(Capabilities::VIEW_ALL)) {
            if ($filters['accountant_user_id'] > 0) {
                $where[] = 'c.accountant_user_id = %d';
                $args[] = (int) $filters['accountant_user_id'];
            }
        } else {
            if (! current_user_can(Capabilities::VIEW_ASSIGNED)) {
                throw new DomainException('SafeContracts counterparty data is outside the current user scope.');
            }
            $where[] = 'c.accountant_user_id = %d';
            $args[] = get_current_user_id();
        }
        if ($filters['customer_id'] > 0) {
            $where[] = 'c.customer_id = %d';
            $args[] = (int) $filters['customer_id'];
        }
        if ($filters['counterparty_type'] !== '') {
            $where[] = 'c.counterparty_type = %s';
            $args[] = (string) $filters['counterparty_type'];
        }
        if ($filters['counterparty_id'] > 0) {
            $where[] = 'c.counterparty_id = %d';
            $args[] = (int) $filters['counterparty_id'];
        }
        if ($filters['contract_id'] > 0) {
            $where[] = 'c.id = %d';
            $args[] = (int) $filters['contract_id'];
        }
        if ($filters['financial_direction'] !== '') {
            $where[] = 'c.financial_direction = %s';
            $args[] = (string) $filters['financial_direction'];
        }
        if ($filters['currency_code'] !== '') {
            $where[] = 'c.currency_code = %s';
            $args[] = (string) $filters['currency_code'];
        }
        if ($filters['status'] !== '') {
            $where[] = 'c.status = %s';
            $args[] = (string) $filters['status'];
        }
        $needle = trim($search);
        if ($needle !== '') {
            if (strlen($needle) > 100) {
                throw new InvalidArgumentException('Contract search must not exceed 100 characters.');
            }
            $like = '%' . addcslashes($needle, "\\%_") . '%';
            $where[] = '(c.contract_number LIKE %s OR cu.name LIKE %s OR su.name LIKE %s OR c.currency_code LIKE %s OR c.status LIKE %s)';
            array_push($args, $like, $like, $like, $like, $like);
        }
        return [$where, $args];
    }

    /** @return list<array<string,mixed>> */
    private function rows(mixed $rows): array
    {
        return is_array($rows) ? array_values(array_filter($rows, 'is_array')) : [];
    }
}
